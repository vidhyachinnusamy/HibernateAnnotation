package com.cts.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	SessionFactory sessionfactory;
	Session session;
	Transaction transaction;

	public void addEmployee(Employee emp) {
		sessionfactory = new Configuration().configure(
				"/resources/hibernate.cfg.xml").buildSessionFactory();
		session = sessionfactory.openSession();
		transaction = session.beginTransaction();
		emp.setEmployeeName("Sunmathi Ponnusamy");
		emp.setEmailId("sun@gmail.com");
		emp.setContactNo("38952799");
		session.save(emp);
		transaction.commit();
		System.out.println("Data has been inserted successfully");
		session.close();
	}
}
